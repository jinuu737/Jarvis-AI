package com.luna.app;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;

import java.io.OutputStream;

/**
 * Lets Jarvis listen WITHOUT taking the sound away from a reel or video.
 *
 * The normal speech recogniser opens the microphone itself and grabs audio focus, which is what pauses or
 * mutes Instagram, YouTube and music. Here Jarvis records the microphone herself (recording never asks for
 * audio focus) and hands the sound to the recogniser, so other apps keep playing.
 * Needs Android 13 or newer; on older phones {@link #supported()} is false and the old way is used.
 */
final class Ear {
    private static final int RATE = 16000;

    /** After the recogniser refused our audio twice in a row we stop trying it (some phones don't support it). */
    private static volatile int refusals = 0;

    private AudioRecord rec;
    private OutputStream out;
    private volatile boolean go;

    static boolean supported() {
        return Build.VERSION.SDK_INT >= 33 && refusals < 2;
    }

    static void worked() {
        refusals = 0;
    }

    static void refused() {
        refusals++;
    }

    /** Adds the extras that make the recogniser read from our own recording. False means: listen the normal way. */
    boolean attach(Context ctx, Intent intent) {
        return attach(ctx, intent, null);
    }

    /**
     * Same, and it also listens for the end of your sentence: because Jarvis owns the microphone feed, it can hear when you go quiet
     * and close the feed, which makes the recogniser answer straight away. {@code onQuiet} is told (once) when that happens.
     */
    boolean attach(Context ctx, Intent intent, final Runnable onQuiet) {
        if (!supported()) return false;
        stop();
        try {
            if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return false;
            final int size = Math.max(min * 2, 8192);
            AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return false;
            }
            ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
            final OutputStream o = new ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]);
            rec = r;
            out = o;
            go = true;
            r.startRecording();
            Thread t = new Thread(() -> {
                byte[] buf = new byte[4096];
                long speechAt = 0, loudAt = 0;
                double floor = 0;
                try {
                    while (go) {
                        int n = r.read(buf, 0, buf.length);
                        if (n > 0) {
                            o.write(buf, 0, n);
                            if (onQuiet != null) {
                                double sum = 0;
                                for (int i = 0; i + 1 < n; i += 2) {
                                    short v = (short) ((buf[i] & 0xff) | (buf[i + 1] << 8));
                                    sum += (double) v * v;
                                }
                                double rms = Math.sqrt(sum / Math.max(1, n / 2));
                                long now = System.currentTimeMillis();
                                floor = floor == 0 ? Math.min(rms, 300) : floor + (rms - floor) * (rms < floor * 1.5 ? 0.03 : 0.002); // the room's background level
                                if (rms > Math.max(floor * 2.5, 450)) { // louder than the room: that's you talking
                                    if (speechAt == 0) speechAt = now;
                                    loudAt = now;
                                }
                                if (speechAt > 0 && (now - loudAt > 600 || now - speechAt > 14000)) {
                                    onQuiet.run();
                                    break; // the feed closes below, and the recogniser gives its answer
                                }
                            }
                        } else if (n < 0) break;
                    }
                } catch (Exception ignored) {
                    // the recogniser closed its end: this round is over
                } finally {
                    try { o.close(); } catch (Exception ignored) { /* already closed */ }
                }
            }, "luna-ear");
            t.setDaemon(true);
            t.start();
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0]);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, RATE);
            return true;
        } catch (Throwable e) {
            stop();
            return false;
        }
    }

    /** Stops recording and closes the pipe. Safe to call any number of times. */
    void stop() {
        go = false;
        AudioRecord r = rec;
        rec = null;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) { /* not started */ }
            try { r.release(); } catch (Exception ignored) { /* already released */ }
        }
        OutputStream o = out;
        out = null;
        if (o != null) {
            try { o.close(); } catch (Exception ignored) { /* already closed */ }
        }
    }
}
