package com.luna.app;

import android.content.Context;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/** "Tell me when Rahul messages me": remembers the names, and says it out loud when one of them writes. */
final class Watch {
    private static final String KEY = "watch";
    private static long lastAt = 0;
    private static String lastWho = "";

    private Watch() { }

    private static Set<String> names(Context ctx) {
        Set<String> out = new LinkedHashSet<>();
        for (String n : ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).getString(KEY, "").split("\n")) if (!n.trim().isEmpty()) out.add(n.trim());
        return out;
    }

    static String set(Context ctx, String name, boolean on) {
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (n.isEmpty()) return "error: whose messages should I watch for?";
        Set<String> all = names(ctx);
        if (on) all.add(n); else all.remove(n);
        ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).edit().putString(KEY, String.join("\n", all)).apply();
        if (!on) return "ok: not watching " + name + " any more";
        NotificationStore.ensureConnected(ctx);
        return NotificationStore.enabled(ctx) ? "ok: I'll tell you when " + name + " messages you"
                : "ok: saved, but turn on Notification access for Jarvis in Settings or I can't see messages";
    }

    static void onMessage(Context ctx, String sender, String app) {
        try {
            long now = System.currentTimeMillis();
            for (String n : names(ctx)) {
                if (!NotificationStore.same(sender, n)) continue;
                if (sender.equals(lastWho) && now - lastAt < 8000L) return; // one announcement per burst of messages
                lastWho = sender;
                lastAt = now;
                ListenService.announceText(ctx, sender + " messaged you on " + app + ".");
                return;
            }
        } catch (Throwable ignored) {
            // a bad notification must never break the listener
        }
    }
}
