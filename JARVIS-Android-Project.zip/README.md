# JARVIS Android project

This repository contains the Android application project and GitHub Actions workflow.

## Build an APK on GitHub

1. Upload the **contents** of this ZIP to the root of a GitHub repository (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Select **Build JARVIS APK** and choose **Run workflow**, or push to `main`.
4. When the run succeeds, open it and download the `JARVIS-APK` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.

The workflow installs Gradle 8.7 and runs `gradle assembleDebug`; this project does not need a `gradlew` wrapper file.

## Notes

- The debug APK is signed with Android's standard debug signing configuration.
- No private signing keystore is included.
- Configure any AI provider credentials inside the app's supported settings. Never commit API keys to a public repository.
